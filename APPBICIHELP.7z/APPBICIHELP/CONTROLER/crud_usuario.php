<?php
 include "../CONTROLER/BD.php";

if (isset($_POST['crud_usuario'])){
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    /*$usuario = $_POST['usuario'];
    $confirmar_usuario = $_POST['confirmar_usuario'];*/
    $contrasena = $_POST['contrasena'];
    $confirmar_contrasena = $_POST['confirmar_contrasena'];
    

    $query = "INSERT INTO perfil_usuario(nombre_completo,usuario,contrasena,confirmar_contrasena,email,confirmar_email) 
    VALUES('$nombre_completo', '$usuario', '$contrasena', '$confirmar_contrasena', '$email', '$confirmar_email')";
    $result = mysqli_query($conn, $query);
    if(!$result){
        die("query failed");
   
    }
    echo "guardado";
}

?>
