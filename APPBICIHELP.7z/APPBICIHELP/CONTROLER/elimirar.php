<?php
include "../CONTROLER/BD.php";
 if (isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "DELETE FROM perfil_usuario WHERE id = $id";
    $result = mysqli_query($conn, $query);

    if(!$result){
        die("query failed");
    }
  


 }

?>
