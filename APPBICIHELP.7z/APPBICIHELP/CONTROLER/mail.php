<?php
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$mensaje = $_POST['mensaje'];
var_dump($nombre);
$rta = mail('h.d.g.c789@gmail.com','mensaje desde la web',$mensaje);
var_dump($rta);
?>