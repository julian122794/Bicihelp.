<?php
// Conectar a la base de datos
require 'BD.php';

try {
    // Verificar si el formulario fue enviado
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Recibir los datos del formulario y limpiarlos
        $nombres = trim($_POST['nombres']);
        $apellidos = trim($_POST['apellidos']);
        $fecha_nacimiento = trim($_POST['fecha_nacimiento']);
        $usuario = trim($_POST['usuario']);
        $cedula_ciudadania = trim($_POST['cedula_ciudadania']);
        $contrasena = $_POST['contrasena'];
        $contrasena_confirmar = $_POST['contrasena_confirmar'];
        $id_cargo = 2; // Valor predeterminado

        // Validar entradas
        if (empty($nombres) || empty($apellidos) || empty($fecha_nacimiento) || empty($usuario) || empty($cedula_ciudadania) || empty($contrasena)) {
            die("Todos los campos son obligatorios.");
        }

        if (!filter_var($usuario, FILTER_VALIDATE_EMAIL)) {
            die("El correo electrónico no es válido.");
        }

        if ($contrasena !== $contrasena_confirmar) {
            die("Las contraseñas no coinciden. Por favor, intente de nuevo.");
        }

        // Encriptar la contraseña
        $contrasena_hash = MD5($contrasena);

        // Preparar la consulta SQL
        $sql = "INSERT INTO registro (nombres, apellidos, fecha_nacimiento, usuario, cedula_ciudadania, contrasena, id_cargo)
                VALUES (:nombres, :apellidos, :fecha_nacimiento, :usuario, :cedula_ciudadania, :contrasena, :id_cargo)";

        // Preparar la consulta
        $stmt = $conn->prepare($sql);

        // Vincular parámetros
        $stmt->bindParam(':nombres', $nombres);
        $stmt->bindParam(':apellidos', $apellidos);
        $stmt->bindParam(':fecha_nacimiento', $fecha_nacimiento);
        $stmt->bindParam(':usuario', $usuario);
        $stmt->bindParam(':cedula_ciudadania', $cedula_ciudadania);
        $stmt->bindParam(':contrasena', $contrasena_hash);
        $stmt->bindParam(':id_cargo', $id_cargo, PDO::PARAM_INT);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            echo "<script>
                    alert('Usuario registrado exitosamente.');
                    setTimeout(function() {
                        window.location.href = '../VIEW/Inicio_sesion.php';
                    }, 3000); // Redirige después de 3 segundos
                  </script>";
        } else {
            echo "Error al registrar el usuario.";
        }
    }
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>