<?php
require 'BD.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    try {
        //consulta para verificar usuario
        $query = $conn->prepare("SELECT * FROM registro WHERE usuario = :usuario");
        $query->bindParam(':usuario', $usuario);
        $query->execute();
        $user = $query->fetch(PDO::FETCH_ASSOC);
        
        if ($user && md5($contrasena) == $user['contrasena']){
            //Inicio de sesión exitoso
            echo "Inicio de Sesión Exitoso Bienvenido, " . htmlspecialchars($user['usuario']);
            switch ($user['id_cargo']) {
                case 1:
                    header("location: ../VIEW/super_usuario.php");
                    break;
                case 2:
                    header("location: ../VIEW/perfil_usuario.php");
                    break;
                case 3:
                    header("location: ../VIEW/perfil_contratista.php");
                    break;
            }
            
            } else {
                //Credenciales invalidas
                echo "Correo o contraseña incorrectos.";
            }

    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>