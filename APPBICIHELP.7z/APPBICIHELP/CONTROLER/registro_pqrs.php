<?php
// Conectar a la base de datos
require 'BD.php'; // Asegúrate de que aquí se cree la instancia $conn con PDO

// Procesar formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger datos del formulario
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $pqrs = $_POST["pqrs"];
    $fecha_mensaje = date("Y-m-d H:i:s");

    try {
        // Preparar e insertar en la base de datos
        $sql = "INSERT INTO pqrs (nombre, email, pqrs, fecha_mensaje) 
                VALUES (:nombre, :email, :pqrs, :fecha_mensaje)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':pqrs', $pqrs);
        $stmt->bindParam(':fecha_mensaje', $fecha_mensaje);

        if ($stmt->execute()) {
            // Enviar correo
            $to = "info@bicihelp.com.co";
            $subject = "Nuevo mensaje de contacto";
            $message = "Nombre: $nombre\nCorreo: $email\n\nMensaje:\n$pqrs";
            $headers = "From: $email";

            if (mail($to, $subject, $message, $headers)) {
                echo "Mensaje enviado y guardado correctamente.";
            } else {
                echo "Error al enviar el correo.";
            }
        } else {
            echo "Error al guardar en la base de datos.";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

// PDO no necesita cierre manual de conexión
?>
