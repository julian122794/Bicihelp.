<?php
$host = 'localhost';
$dbname = 'bicihelp';
$username = 'root';
$password = '';

try{
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charse=uft8",$username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
}catch (PDOException $e){
    die("Error de conexion: " . $e->getMessage());
}
?>