<?php
// Conexión a la base de datos
require 'BD.php'; // Archivo que contiene la conexión PDO ($conn)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $cedula_ciudadania = $_POST['cedula_ciudadania'];
    $telefono = $_POST['telefono'];
    $ciudad = $_POST['ciudad'];
    $contrasena = $_POST['contrasena'];
    $usuario = "correo@example.com"; // Este valor debe venir de la sesión del usuario autenticado

    try {
        // Encriptar la nueva contraseña
        $contrasena_hash = password_hash($contrasena, PASSWORD_DEFAULT);

        // Actualizar los datos en la base de datos
        $sql = "UPDATE registro 
                SET nombres = :nombres,
                    apellidos = :apellidos,
                    fecha_nacimiento = :fecha_nacimiento,
                    cedula_ciudadania = :cedula_ciudadania,
                    telefono = :telefono,
                    ciudad = :ciudad,
                    contrasena = :contrasena
                WHERE usuario = :usuario";

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nombres', $nombres);
        $stmt->bindParam(':apellidos', $apellidos);
        $stmt->bindParam(':fecha_nacimiento', $fecha_nacimiento);
        $stmt->bindParam(':cedula_ciudadania', $cedula_ciudadania);
        $stmt->bindParam(':telefono', $telefono);
        $stmt->bindParam(':ciudad', $ciudad);
        $stmt->bindParam(':contrasena', $contrasena_hash);
        $stmt->bindParam(':usuario', $usuario);

        if ($stmt->execute()) {
            echo "<p>Datos actualizados correctamente.</p>";
        } else {
            echo "<p>Error al actualizar los datos.</p>";
        }
    } catch (PDOException $e) {
        echo "<p>Error: " . $e->getMessage() . "</p>";
    }
}
?>
