const carouselSlide = document.querySelector('.carousel-slide');
const carouselItems = document.querySelectorAll('.carousel-item');
const prevButton = document.querySelector('.prev');
const nextButton = document.querySelector('.next');

let counter = 0;
const size = carouselItems[0].clientWidth;

nextButton.addEventListener('click', () => {
    if (counter >= carouselItems.length - 1) return;
    carouselSlide.style.transform = 'translateX(' + (-size * ++counter) + 'px)';
});

prevButton.addEventListener('click', () => {
    if (counter <= 0) return;
    carouselSlide.style.transform = 'translateX(' + (-size * --counter) + 'px)';
});
