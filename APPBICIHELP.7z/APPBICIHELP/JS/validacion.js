/*onst inputs = document.querySelectorAll('#formulario input');

const expresiones = {
    usuario:/^[a-zA-Z0_9\_\-]{4,16}$/,//letras,numeros,guion y guion bajo
    nombre:/^[a-zA-ZÀ-Ÿ\s]{1,40}$/,//letras y espacios pueden llevar acentos
    password:/^[a-zA-Z]{4,12}$/,//letras mayusculas 4 a 14 dijitos
    correo:/^[a-zA-Z0-9_.+-]+"@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
    telefono:/^\d{7-14}$/,//7 a 14 numeros

}

inputs.forEach((input) =>{
    input.addEventListener('keyup',()=>{
        console.log('tecla levantada');
    });

});
    formulario.addEventListener('submit', (e) => {
        e.preventDefault();
});*/

const formulario = document.getElementById('formulario');
const inputs = document.querySelectorAll('#formulario input');

const expresiones = {
	
	username: /^[a-zA-ZÀ-ÿ\s]{1,40}$/,
    lastename: /^[a-zA-ZÀ-ÿ\s]{1,40}$/, // Letras y espacios, pueden llevar acentos.
    date: /^[a-zA-Z,]+$/, //
    email: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
    documento: /^[a-zA-Z0-9_.+-]+[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
    telefono: /^\d{7,14}$/,// 7 a 14 numeros.
    ciudad:/^[a-zA-ZÀ-ÿ\s]{1,20}$/,
	password: /^.{4,12}$/, // 4 a 12 digitos.
}

const validarFormulario = (e) =>{
 switch (e.target.name) {
    case "username":
   if(expresiones.username.test(e.target.value)){
    document.querySelector('#group-username.formulario__group-input-error').classList.remove('formulario__group-input-error-activo');
 }else{
    document.querySelector('#group-username.formulario__group-input-error').classList.add('formulario__group-input-error-activo');
 }
 break;
}
}

inputs.forEach((input) => {
    input.addEventListener('keyup',validarFormulario);
    input.addEventListener('blur',validarFormulario);
 });

 formulario.addEventListener('submit', (e) => {
    e.preventDefault();
   
});
