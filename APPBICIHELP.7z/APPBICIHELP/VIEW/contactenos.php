<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contáctenos | BiciHelp</title>
    <link rel="stylesheet" href="../CSS/contactenos.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <img src="../IMG/logo.jpg" width="100" height="100" alt="Logo de BiciHelp">
            <div class="logo">
                <h1>BiciHelp</h1>
            </div>
    </header>

    <nav>
        <ul>
            <li><a href="../VIEW/Inicio.php">Inicio</a></li>
            <li><a href="../VIEW/Nosotros.php">Quiénes somos</a></li>
            <li><a href="../VIEW/contactenos.php">Contáctenos</a></li>
            <li><a href="../VIEW/Servicios.php">Servicios</a></li>
            <li><a href="../VIEW/selecc_t_registo.php">Registrarse</a></li>
            <li><a href="../VIEW/Inicio_sesion.php">Inicio de sesión</a></li>
            <li><a href="../VIEW/chat.php">Chat</a></li>
        </ul>
    </nav>

    <main class="principal">
        <div class="container-form">
            <div class="info-form">
                <h2>Contáctanos</h2>
                <p>¡Bienvenido a nuestro Taller de Bicicletas! Si tienes preguntas o deseas más información sobre nuestros servicios, no dudes en contactarnos. Estamos aquí para mantener tu bicicleta en perfectas condiciones.</p>
                <p>Puedes contactarnos a través del formulario, llamarnos o visitarnos en nuestro taller.</p>
                <p>¡Estamos listos para ayudarte a seguir pedaleando sin preocupaciones!</p>
                <p><i class="bx bxs-phone"></i> 3165338316</p>
                <p><i class="bx bxs-envelope"></i> contacto@bicihelp.com.co</p>
                <p><i class="bx bxs-map"></i> Bogotá, Colombia</p>
            </div>

            <form method="post" action="../CONTROLER/registro_pqrs.php" autocomplete="off">
                <div class="input-group">
                    <label for="nombre" class="subtitle">Nombre Completo</label>
                    <input type="text" id="nombre" name="nombre" placeholder="Ingrese su nombre" class="campo" required>
                </div>
                <div class="input-group">
                    <label for="email" class="subtitle">Correo Electrónico</label>
                    <input type="email" id="email" name="email" placeholder="Ingrese su correo" class="campo" required>
                </div>
                <div class="input-group">
                    <label for="pqrs" class="subtitle">Quejas o Sugerencias</label>
                    <textarea id="pqrs" name="pqrs" placeholder="Ingrese su mensaje" required></textarea>
                </div>
                <button type="submit" name="enviar">Enviar Mensaje</button>
            </form>
        </div>
    </main>

    <?php include("footer.php"); ?>
</body>
</html>
