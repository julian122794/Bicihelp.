<html>


<footer>
        <p>&copy; 2024 BiciHelp. Todos los derechos reservados.</p>
        
</footer>

</html>
 
<?php

    /*include("footer.php")*/
?>
