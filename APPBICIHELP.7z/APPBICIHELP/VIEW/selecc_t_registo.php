<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" href="../CSS/Inicio.css">
</head>

<body>
    
    <header>
        <img src="../IMG/logo.jpg" width="100" height="100" alt="25">
            <div class = "logo">
                <h1>Seleccionar tipo registro</h1>
            </div>
          
    </header>
    
    <nav>
        <ul>
            <li><a href="../VIEW/Inicio.php">Inicio</a></li>
            <li><a href="../VIEW/chat.php">Chat</a></li>
        </ul>
    </nav>

    <main class ="principal">

    <div class="login-container">
        <form class="button-container">
            <img src="../IMG/user-solid-72.png" width="72px">
            <a href="../VIEW/form_registro_usuarios.php" target="_blank">
            <button type="button">Registrar Usuario</button>
        </form>
            
        <form class="button-container">
            <img src="../IMG/wrench-solid-72.png" width="72px">
            <a href="../VIEW/form_registro_contratista.php" target="_blank">
            <button type="button">Registrar Técnico</button>
        </form>
    </div>

  </main>
    <?php
        include("footer.php")
    ?>
</body>
</html>
