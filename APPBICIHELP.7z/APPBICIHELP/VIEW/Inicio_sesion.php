<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" href="../CSS/Styles.css">
</head>

<body>
    
    <header>
        <img src="../IMG/logo.jpg" width="100" height="100" alt="LOGO">
            <div class = "logo">
                <h1>Iniciar Sesión</h1>
            </div>
          
    </header>
    
    <nav>
        <ul>
            <li><a href="../VIEW/Inicio.php">Inicio</a></li>
            <li><a href="../VIEW/chat.php">Chat</a></li>
        </ul>
    </nav>

    <main class="content">
        <div class="login-container">   
            <form action="../CONTROLER/ingreso.php" method="POST">
                <div class="input-group">
                        <label for="usuario">Usuario</label>
                        <input type="email" name="usuario" required placeholder="Email registrado"><br><br>
                </div>
                <div class="input-group">
                        <label for="contrasena">Contraseña</label>
                        <input type="password" name="contrasena" required placeholder="Contraseña">
                        <span class="eye-icon">&#128065;</span><br><br>
                </div>
                    
                <a href="../VIEW/recuperarcontraseña.php">¿olvidaste tu contraseña?</a>  </br></br>
                <button type="submit">Iniciar Sesión</button>
                <br></br>
                <!-- <button type="submit">Iniciar con GOOGLE</button>
                <br></br>
                <button type="submit">Iniciar con IOS </button></br></br>-->
                <div>
                    <button type="text" href="../VIEW/Inicio.php">volver</button>
                </div>
            </form>
        </div>
    </main>
    <?php
        include("footer.php")
    ?>
</body>
</html>
