<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil Superusuario</title>
    <link rel="stylesheet" href="../CSS/super_usuario.css">
</head>


<header>
        <img src="../IMG/logo.jpg" width="100" height="100" alt="LOGO">
            <div class = "logo">
                <h1>Gestión de usuarios y permisos</h1>
            </div>

        
</header>

<nav>
    <ul>
    <li><a href="../VIEW/Inicio.php">Inicio</a></li>
            <li><a href="../VIEW/Nosotros.php">Quienes somos</a></li>
            <li><a href="../VIEW/contactenos.php">Contactenos</a></li>
            <li><a href="../VIEW/Servicios.php">Servicios</a></li>
            <li><a href="../VIEW/selecc_t_registo.php">Registrarse</a></li>
            <li><a href="../VIEW/Inicio_sesion.php">Inicio de sesion</a></li>
            <li><a href="../VIEW/chat.php">Chat</a></li>
    </ul>
</nav>

<main>
<body>
    <div class="container">
        <!-- Profile Card -->
        <div class="profile-card">
            <div class="profile-image">
                <img src="https://via.placeholder.com/150" alt="Profile Picture">
            </div>
            <h2>Superusuario</h2>
            <p>Gestiona todos los usuarios y contratistas</p>
            <button class="upload-btn">Subir nueva foto</button>
            <p class="instructions">Sube una nueva foto de perfil. Las imágenes más grandes se redimensionarán automáticamente. <br> El tamaño máximo de carga es 1 MB.</p>
            <p class="member-since">Miembro desde: 20 de noviembre de 2024</p>
        </div>

        <!-- Manage Users and Contractors -->
        <div class="edit-profile">
            <h2>Gestionar Usuarios y Contratistas</h2>
            <form action="perfil_superusuario.php" method="POST">
                <div class="form-group">
                    <label for="new-user-name">Nombre de Usuario</label>
                    <input type="text" id="new-user-name" name="new_user_name" placeholder="Nombre del nuevo usuario" required>
                </div>
                <div class="form-group">
                    <label for="new-user-role">Rol del Usuario</label>
                    <select id="new-user-role" name="new_user_role" required>
                        <option value="usuario">Usuario</option>
                        <option value="contratista">Contratista</option>
                        <option value="superusuario">Superusuario</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="new-user-email">Correo Electrónico</label>
                    <input type="email" id="new-user-email" name="new_user_email" placeholder="Correo del nuevo usuario" required>
                </div>
                <div class="form-group">
                    <label for="new-user-phone">Teléfono</label>
                    <input type="text" id="new-user-phone" name="new_user_phone" placeholder="Número de teléfono" required>
                </div>
                <div class="form-group">
                    <label for="new-user-password">Contraseña</label>
                    <input type="password" id="new-user-password" name="new_user_password" placeholder="Nueva Contraseña" required>
                </div>
                <div class="form-group">
                    <label for="confirm-password">Confirmar Contraseña</label>
                    <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirmar contraseña" required>
                </div>
                <button type="submit" name="create_user" class="update-btn">Crear Nuevo Usuario</button>
            </form>

            <h3>Eliminar Usuario</h3>
            <form action="perfil_superusuario.php" method="POST">
                <div class="form-group">
                    <label for="delete-user-id">ID del Usuario a Eliminar</label>
                    <input type="text" id="delete-user-id" name="delete_user_id" placeholder="Ingrese el ID del usuario a eliminar" required>
                </div>
                <button type="submit" name="delete_user" class="update-btn">Eliminar Usuario</button>
            </form>

            <h3>Actualizar Usuario</h3>
            <form action="perfil_superusuario.php" method="POST">
                <div class="form-group">
                    <label for="update-user-id">ID del Usuario</label>
                    <input type="text" id="update-user-id" name="update_user_id" placeholder="ID del usuario para actualizar" required>
                </div>
                <div class="form-group">
                    <label for="update-email">Nuevo Correo Electrónico</label>
                    <input type="email" id="update-email" name="update_email" placeholder="Nuevo correo electrónico" required>
                </div>
                <div class="form-group">
                    <label for="update-phone">Nuevo Teléfono</label>
                    <input type="text" id="update-phone" name="update_phone" placeholder="Nuevo número de teléfono" required>
                </div>
                <button type="submit" name="update_user" class="update-btn">Actualizar Usuario</button>
            </form>
        </div>
    </div>
    <br><br><br><br><br><br><br>

    <?php
        include("footer.php")
    ?>
    
</body>
</html>


