<html>
    <head>
        <title>
            BICI-HELPrecuperarcontraseña
        </title>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="../CSS/style.css">   
    </head>
    <body>
    <header>
    <img src="../IMG/logo.jpg" width="130" height="160" alt="25">
        <div class = "logo">
         
        <h1>Bienvenido a BiciHelp</h1>
        </div>
    </header>
           
     <nav>
        <ul>
            <li><a href="../VIEW/Inicio.php">Inicio</a></li>
            <li><a href="../VIEW/Nosotros.php">Quienes somos</a></li>
            <li><a href="../VIEW/contactenos.php">Contactenos</a></li>
            <li><a href="../VIEW/Servicios.php">servicios</a></li>
            <li><a href="../VIEW/Registro_contratista.php">Registrarse</a></li>
            <li><a href="../VIEW/Inicio_sesion.php">Inicio de sesion</a></li>
            <li><a href="../VIEW/chat.php">Chat</a></li>
        </ul>
    </nav>

           

            <div class="recuperar">
            <h2>
                recuperar contraseña
            </h2>
                <label for="nombre">para recuperar su contraseña, escriba su correo electronico</label>
                <form action="recuperarcontraseña.php" class="form" method="POST">
                  
                    <div class="form__correo">
                      
                        <input type="email"id="email" name="email" placeholder="ingresar su correo" class="correo"></br></br>
                        <button type="submit" value="enviar"name="enviar">continuar</button>
                    </div>
                    

                </form>

            </div>
    </body>
    
    <?php

include("footer.php")
?>

</html>
