<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Usuario</title>
    <link rel="stylesheet" href="../CSS/Styles.css">
</head>
<body>
    <header>
        <img src="../IMG/logo.jpg" width="100" height="100" alt="25"alt="LOGO">
        <div class="logo">
            <h1>Registro Usuarios</h1>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="../VIEW/Inicio.php">Inicio</a></li>
            <li><a href="../VIEW/chat.php">Chat</a></li>
        </ul>
    </nav>

    <main class="content">
        <div class="login-container">
            <h2>Registro Usuarios</h2>
            <form action="../CONTROLER/registro_usuario.php" method="POST">
                <div class="input-group">
                    <label for="nombres">Nombres:</label>
                    <input type="text" id="nombres" name="nombres" required>
                </div>

                <div class="input-group">
                    <label for="apellidos">Apellidos:</label>
                    <input type="text" id="apellidos" name="apellidos" required>
                </div>

                <div class="input-group">
                    <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                    <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>
                </div>

                <div class="input-group">
                    <label for="cedula_ciudadania">Cédula de Ciudadanía:</label>
                    <input type="text" id="cedula_ciudadania" name="cedula_ciudadania" required>
                </div>

                <div class="input-group">
                    <label for="usuario">Email (Usuario):</label>
                    <input type="email" id="usuario" name="usuario" required>
                </div>

                <div class="input-group">
                    <label for="contrasena">Contraseña:</label>
                    <div class="password-wrapper">
                        <input type="password" id="contrasena" name="contrasena" required>
                        <span class="eye-icon" onclick="togglePassword('contrasena', this)">&#128065;</span>
                    </div>
                </div>

                <div class="input-group">
                    <label for="contrasena_confirmar">Confirmar Contraseña:</label>
                    <div class="password-wrapper">
                        <input type="password" id="contrasena_confirmar" name="contrasena_confirmar" required>
                        <span class="eye-icon" onclick="togglePassword('contrasena_confirmar', this)">&#128065;</span>
                    </div>
                </div>

                <button type="submit">Registrar</button>
            </form>
        </div>
    </main>

    <?php include("footer.php"); ?>
</body>
</html>
