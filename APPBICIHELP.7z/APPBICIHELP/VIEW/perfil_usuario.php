<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualización información usuario</title>
    <link rel="stylesheet" href="../CSS/super_usuario.css">
</head>


<header>
        <img src="../IMG/logo.jpg" width="100" height="100" alt="LOGO">
            <div class = "logo">
                <h1>Gestión de información de usuario</h1>
            </div>

        
</header>

<nav>
    <ul>
    <li><a href="../VIEW/Inicio.php">Inicio</a></li>
            <li><a href="../VIEW/Nosotros.php">Quienes somos</a></li>
            <li><a href="../VIEW/contactenos.php">Contactenos</a></li>
            <li><a href="../VIEW/Servicios.php">Servicios</a></li>
            <li><a href="../VIEW/selecc_t_registo.php">Registrarse</a></li>
            <li><a href="../VIEW/Inicio_sesion.php">Inicio de sesion</a></li>
            <li><a href="../VIEW/chat.php">Chat</a></li>
    </ul>
</nav>

<main>
<body>
    <div class="container">
        <h1>Actualizar Perfil</h1>
        <form method="POST" action="../CONTROLER/actualizar_perfil.php" class="formulario">
            <label for="nombres">Nombres:</label>
            <input type="text" id="nombres" name="nombres" placeholder="Ingrese sus nombres" required>

            <label for="apellidos">Apellidos:</label>
            <input type="text" id="apellidos" name="apellidos" placeholder="Ingrese sus apellidos" required>

            <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
            <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>

            <label for="cedula_ciudadania">Cédula de Ciudadanía:</label>
            <input type="text" id="cedula_ciudadania" name="cedula_ciudadania" placeholder="Ingrese su cédula" required>

            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" placeholder="Ingrese su teléfono" required>

            <label for="ciudad">Ciudad:</label>
            <input type="text" id="ciudad" name="ciudad" placeholder="Ingrese su ciudad" required>

            <label for="contrasena">Nueva Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" placeholder="Ingrese su nueva contraseña" required>

            <button type="submit">Actualizar Datos</button>
        </form>
    </div>
</body>
</main>
</html>
