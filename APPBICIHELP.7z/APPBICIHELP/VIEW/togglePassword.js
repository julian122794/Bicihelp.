function togglePassword(inputId, icon) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
        input.type = "text";
        icon.innerHTML = "&#128064;"; // Cambiar el ícono si lo deseas
    } else {
        input.type = "password";
        icon.innerHTML = "&#128065;";
    }
}
